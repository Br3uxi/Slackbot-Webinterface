<?php

$channel = $_POST['channel'];
$message = $_POST['message'];

?>
